import React from 'react';
import Movies from './Components/Movies/Movies'

/** NM : Semicolon missing as the end of the line
 * Name of folder should be generally small. So Components become components
*/


/** NM: Make use of arrow functions
 * 
 * export const App = () => {
 * 
 * }
 * 
 *  **/

 /** NM : Indenatation at line 21*/
function App() {
  return (
    <div>
     <Movies/>
    </div>
  );
}

export default App;
