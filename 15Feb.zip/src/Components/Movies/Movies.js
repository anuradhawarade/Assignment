import React, { useState, useEffect } from "react";
import * as actions from "../../redux/actions/action";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { LazyLoadImage } from "react-lazy-load-image-component";
import Header from "../Header/Header";
import ErrorBoundary from '../ErrorBoundry/ErrorBoundary'
const Movies = (props) => {
  const [OnLoad, setOnLoad] = useState(true);
  const [LoadMovie, setLoadMovie] = useState([]);
  const [LoadList,setLoadList]=useState()
  //on Load First json will be loaded
  useEffect(() => {
   if(OnLoad===true)
    props.GetActions.LoadPage1();
  }, [OnLoad]);

  useEffect(() => {
    if (props.MovieList1) {
      setLoadMovie(props.MovieList1.page["content-items"].content);
    }
  }, [props.MovieList1]);

  useEffect(() => {
    if (props.MovieList2) {   
       let list=props.MovieList2.page["content-items"].content
       let existinglist=[...LoadMovie]
       list.map((item,index)=>{existinglist.splice(LoadMovie.length+index,0,item)})       
       setLoadMovie(existinglist);
    }
  }, [props.MovieList2]);

  useEffect(() => {
    if (props.MovieList3) {
      let list=props.MovieList3.page["content-items"].content
      let existinglist=[...LoadMovie]
      list.map((item,index)=>{existinglist.splice(LoadMovie.length+index,0,item)})       
      setLoadMovie(existinglist);
    }
  }, [props.MovieList3]);
  
  const handleScroll=(e)=>{
    
    if(LoadMovie && LoadMovie.length>0 && LoadMovie.filter(item=>item.IsLoad==true).length==LoadMovie.length)
    {
      
       if(props.MovieList2==undefined)props.GetActions.LoadPage2();
       else
       if(props.MovieList3==undefined)props.GetActions.LoadPage3();
    }
  } 
  const handleLoad=(e,item,index)=>{
    
    if(LoadMovie && LoadMovie.length>0 && LoadMovie.filter(item=>item.IsLoad==true).length<LoadMovie.length)
    {
      
      let UpdatedList=  LoadMovie.map((item,_index)=>{
        let copy=item
        if(_index==index)
        {
          copy.IsLoad=true
        }
        return copy
      })
       setLoadMovie(UpdatedList)
    }
  }

  return (
    <ErrorBoundary>
    <div className="bg-black text-white">
      <Header />
      <div className="w-full flex">
        <div
          className="ml-3 h-screen w-30 motion-safe:animate-fadeIn column"
          onScroll={handleScroll}
        >

            {LoadMovie && LoadMovie.length>0 &&
            LoadMovie.map((item, index) => {
             
             
               let ImageUrl=undefined
               try{
                ImageUrl=require(`../../Assets/Slices/${item["poster-image"]}`)
               }
               catch
               {
                 ImageUrl= `../../Assets/Slices/placeholder_for_missing_posters.png`
               }
             return(
              <div className="SubItem">
                <LazyLoadImage
                  key={`Col1_${item.name}_${index}`}
                  effect="blur"
                  alt={item.name}
                  src={ImageUrl} // use normal <img> attributes as props
                  afterLoad={(e)=>handleLoad(e,item,index)}
                />
                <span  className="mt-3 caption">{item.name}</span>
              </div>)
           
              })}
        </div>
        <div
          className="ml-3 h-screen w-30 motion-safe:animate-fadeIn column"
          
        >
          {LoadMovie && LoadMovie.length>0 &&
            LoadMovie.map((item, index) => {
              let ImageUrl=undefined
              try{
               ImageUrl=require(`../../Assets/Slices/${item["poster-image"]}`)
              }
              catch
              {
                ImageUrl= `../../Assets/Slices/placeholder_for_missing_posters.png`
              }
             return( <>
                <div className="SubItem">
                  <LazyLoadImage
                    key={`Col2_${item.name}_${index}`}
                    effect="blur"
                    alt={item.name}
                    src={require(`../../Assets/Slices/${item["poster-image"]}`)} // use normal <img> attributes as props
                  />
                  <span className="mt-3 caption">{item.name}</span>
                </div>
              </>)
})}
        </div>
        <div
          className="ml-3 mr-3 h-screen w-30 motion-safe:animate-fadeIn column"
          
        >
          {LoadMovie && LoadMovie.length>0 &&
            LoadMovie.map((item, index) => {

              let ImageUrl=undefined
              try{
               ImageUrl=require(`../../Assets/Slices/${item["poster-image"]}`)
              }
              catch
              {
                ImageUrl= `../../Assets/Slices/placeholder_for_missing_posters.png`
              }
              return(
              <>
                <div className="SubItem">
                  <LazyLoadImage
                    key={`Col3_${item.name}_${index}`}
                    effect="blur"
                    alt={item.name}
                    src={require(`../../Assets/Slices/${item["poster-image"]}`)} // use normal <img> attributes as props
                  />
                  <span className="mt-3 caption">{item.name}</span>
                </div>
              </>)
        })}
        </div>
      </div>
    </div>
  </ErrorBoundary>
  );
};

const mapDispatchToProps = (dispatch) => {
  return {
    GetActions: bindActionCreators(actions, dispatch),
  };
};

function mapStateToProps(state /*, ownProps*/) {
  return {
    MovieList1: state.Page1,
    MovieList2: state.Page2,
    MovieList3: state.Page3,
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(Movies);
