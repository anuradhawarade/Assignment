import React from 'react';
import Back from '../../Assets/Slices/Back.png'
import search from '../../Assets/Slices/search.png'
function Header(props) {
    return (
        <div className="w-full flex h-16">
            <img src={Back} className="h-3 BackButton" alt="back"/>
            <span className="HeaderText">Romantic Comedy</span>
            <img src={search} className="h-3 SearchButton" alt="search" />
        </div>
    );
}

export default Header;