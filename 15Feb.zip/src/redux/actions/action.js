const GET_PAGE_1 = 'GET_PAGE_1'
const GET_PAGE_2 = 'GET_PAGE_2'
const GET_PAGE_3 = 'GET_PAGE_3'





export const LoadPage1 = () => {
    return { type: GET_PAGE_1 }
}

export const LoadPage2 = () => {
    return { type: GET_PAGE_2 }
}

export const LoadPage3 = () => {
    return { type: GET_PAGE_3 }
}
