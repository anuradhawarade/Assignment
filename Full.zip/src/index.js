/** NM : Always arrange the imports in following order:
  1. react imports & third party
  2. Internal files
  3. css files
**/

/** NM : Error while running the code
 * npm start: Module not found: Can't resolve '@fortawesome/free-solid-svg-icons' in
 * 'C:\Users\nikita.y.m\OneDrive - Accenture\ReactJS-Bootcamp-2020\react-readiness\Day 4\xd.react.readiness\src\Components\Header'
 */
import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';
import {store} from './redux/store'
import {Provider as ReduxProvider} from 'react-redux'
import 'tailwindcss/dist/tailwind.min.css'
import './App.css'
/** NM : Always use proper indentation **/
ReactDOM.render(
  <ReduxProvider store={store}>
  <React.StrictMode>
    <App />
  </React.StrictMode>
  </ReduxProvider>,
  document.getElementById('root')
);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
