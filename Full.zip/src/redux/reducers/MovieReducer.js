import page1 from '../../Assets/API/CONTENTLISTINGPAGE-PAGE1.json'
import page2 from '../../Assets/API/CONTENTLISTINGPAGE-PAGE2.json'
import page3 from '../../Assets/API/CONTENTLISTINGPAGE-PAGE3.json'

const initial = () => {
    return {
       Page1:undefined,
       Page2:undefined,
       Page3:undefined,
    }
}



export const MovieReducer = (state = initial, action) => {

    switch (action.type) {
        case "GET_PAGE_1": return {
            ...state,
            Page1: page1,            
        }
        case "GET_PAGE_2": return {
            ...state,
            Page2: page2,            
        }
        case "GET_PAGE_3": return {
            ...state,
            Page3: page3,            
        }
    
        default: return state
    }

}